# LocalLink - Flask Backend

This is a Flask backend application with user authentication features.

## Setup Instructions

1. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python app.py
```

The application will be available at `http://localhost:5000`

## Features

- User registration
- User login/logout
- Protected routes
- SQLite database for user storage
- Flash messages for user feedback

## Routes

- `/` - Home page
- `/login` - Login page
- `/register` - Registration page
- `/logout` - Logout (protected route)
- `/shops` - Shops page
- `/offers` - Offers page
- `/delivery` - Delivery page 